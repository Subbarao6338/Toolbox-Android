# Omni Browser and Toolbox (`omni.browser.toolbox`)

[![License: AGPL v3](https://img.shields.io/badge/License-AGPL_v3-blue.svg)](https://www.gnu.org/licenses/agpl-3.0)
[![Platform: Android](https://img.shields.io/badge/Platform-Android-green.svg)](https://developer.android.com)
[![Status: Fully Featured](https://img.shields.io/badge/Status-Fully_Featured-brightgreen.svg)](https://github.com/Subbarao6338/omni-browser-toolbox)
[![No Ads, Tracker Free](https://img.shields.io/badge/Privacy-No_Ads_%2F_No_Tracking-success.svg)](https://github.com/Subbarao6338/omni-browser-toolbox)

**Omni Browser and Toolbox** is an ultimate, all-in-one, fully-fledged Android
application that seamlessly merges an ultra-secure, blazing-fast,
highly-customizable web browser with a multi-purpose modular engineering
and productivity toolbox.

Built with modern **Android Jetpack Compose**, **Kotlin Coroutines / Flow**,
**Hilt / Dagger**, **Room DB**, and designed under strict clean-architecture
MVVM/MVI principles, Omni Browser and Toolbox delivers an unmatched
professional-grade mobile experience without compromises.

---

## 🚫 Core Commitments

This application is dedicated to the open-source community and strictly
adheres to these ethical guidelines:

- **No Ads:** Absolutely zero advertisement networks, banners, interstitials,
  or promotional pop-ups.
- **No Payments / No Paywalls:** 100% of the features are fully functional
  out of the box with zero financial transactions required.
- **No Donations:** No nagging banners, prompt-ups, or donation links
  cluttering your workspace.
- **No Tracking / No Analytics:** No telemetry, crash reporting, usage logging,
  or tracking cookies are bundled. Your data never leaves your device.

---

## 🧭 Ultimate Browser Engine

Omni Browser features a highly optimized web browser supporting multiple layout
engines and custom configuration controls:

### 1. Unified Tab Architecture & Engine Selection

- **Multi-Engine Runtime:** Switch between system-optimized **Blink/Webkit
  (WebView)** and the privacy-focused **GeckoView (Mozilla)** at runtime.
- **Unlimited Tabs:** Efficient tab-state preservation utilizing SQLite memory
  mapping. Supports vertical list view, grid view, and a horizontal bar.
- **True Incognito & Private Session Mode:** Isolated cookie storage, disabled
  cache, and memory-only history with an instant-wipe panic button.

### 2. Powerful Ad & Tracker Blockers

- **Network Request Interception:** Built-in ad-blocking parser processing
  standard Adblock Plus / uBlock Origin formats (`easylist.txt`,
  `easyprivacy.txt`).
- **Cosmetic Filtering:** Custom CSS injection to remove layout placeholders
  and empty spaces left by blocked ads.
- **Dynamic Javascript Sandbox Control:** Toggle JS execution, cookie
  acceptance, local storage, and geolocation permissions on a per-site or
  global level.

### 3. Deep Browser Customizations

- **Custom User-Agents:** Easily select preset User-Agents (Desktop Chrome,
  Safari iOS, Firefox Linux, Custom Strings) to bypass mobile-only redirects.
- **Display Configurations:** Toggle night-mode rendering (force dark-mode
  CSS), zoom levels, auto-fit text, and reader view layouts.
- **Advanced Navigation Controls:** Double-tap actions, gesture-based swipe
  navigation (swipe edges to go back/forward), custom search engine lists
  (DuckDuckGo, SearXNG, Google, custom URL query).

---

## 🛠️ Integrated Professional Toolbox

Beyond browsing, Omni integrates a full suite of system utilities and
developer tools, ensuring that your device has every utility ready locally.

| Category | Utilities included |
| :--- | :--- |
| **📥 Download Manager** | Multi-threaded downloading, background pause/resume, file segmentation, Torrent (magnet/torrent file) downloader. |
| **📁 File Manager** | Archive manager (ZIP, TAR, GZ, 7z extraction), file system browser, storage analyzer, local web server for quick sharing. |
| **🔐 Cryptography & Hashing** | Symmetric/Asymmetric engines (AES-256, RSA, PGP), digest calculations (MD5, SHA-1, SHA-256, SHA-512, bcrypt), password generator. |
| **🌐 Network Diagnostics** | Ping, Traceroute, Port Scanner, DNS Lookup, IP subnet calculator, WHOIS lookup, packet analyzer (PCAP file viewer). |
| **📝 Editor & IDE Lite** | Markdown parser, text/code editor with syntax highlighting (HTML, CSS, JS, Kotlin, Python, JSON), regex match & replace. |
| **🔄 File & Data Converters** | JSON/XML formatter, Base64 encoder/decoder, URL encoder/decoder, unit converter (physical, currency, digital sizes), image format converter. |
| **🎬 Media Players** | Hardware-accelerated video/audio player supporting background playback, subtitles (.srt), and picture-in-picture (PiP). |

---

## 🎨 Modern UI/UX and Customizations

Built with Jetpack Compose, Omni provides a fluid, Material Design 3 (M3)
user interface that responds smoothly to every device size (phones, tablets,
foldables).

- **Dynamic Theme Engine:** Full support for Material You (Dynamic Colors on
  Android 12+), pure AMOLED black mode, and a large selection of preset color
  themes.
- **Completely Customizable Interface:**
  - Drag-and-drop the home page layout (re-order speed dials, toolbox widgets,
    news RSS feeds, search bars).
  - Move address bars to either the top or bottom of the screen.
  - Custom gesture mapping, toolbar shortcuts, and long-press shortcuts.
- **Hardware Integrations:** Responsive haptics, biometrics locks for private
  files/browser tabs, multi-window screen split, and picture-in-picture
  capability.

---

## 🏗️ Project Architecture

Omni Browser and Toolbox follows clean code paradigms using modern Android
libraries:

```text
omni-browser-toolbox/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/omni/browser/toolbox/
│   │   │   │   ├── core/           # Dependency Injection, Extensions, Common Base UI
│   │   │   │   ├── data/           # Database (Room), Shared Prefs, Network repositories
│   │   │   │   ├── browser/        # WebView and GeckoView layouts, Tabs, Adblock engines
│   │   │   │   ├── toolbox/        # Modular components (Download, Network, Crypto, Editor, etc.)
│   │   │   │   └── ui/             # Jetpack Compose Screens, Navigation, Themes
│   │   │   └── AndroidManifest.xml # Main Manifest including secure intent filters
│   └── build.gradle.kts            # App Gradle Configuration
├── gradle/                         # Wrapper files
├── build.gradle.kts                # Project Root Build Script
└── settings.gradle.kts             # Subproject configurations
```

---

## 🛠️ Build and Compilation Instructions

### Prerequisites

- **JDK 17 or 21**
- **Android SDK (API Level 34 / Android 14)**
- **Gradle 8.8+**

### Building from Command Line

To build the debug APK:

```bash
./gradlew assembleDebug
```

To run all unit and instrumented tests:

```bash
./gradlew test
```

To run Kotlin linter and style check (via ktlint/detekt):

```bash
./gradlew lint
```

The compiled APK will be generated under
`app/build/outputs/apk/debug/app-debug.apk`.

---

## 📄 License

Omni Browser and Toolbox is licensed under the **GNU Affero General Public
License v3.0 (AGPL-3.0)**. Every derivative work, hosted web service, or
modification must also be open-source and distributed under the same license
terms. See the [LICENSE](LICENSE) file for complete details.
