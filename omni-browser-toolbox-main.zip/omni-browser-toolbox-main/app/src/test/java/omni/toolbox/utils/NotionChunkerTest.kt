package omni.toolbox.utils

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class NotionChunkerTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    @Test
    fun testChunkDefaultSize() {
        val items = (1..25).toList()
        val chunks = NotionChunker.chunk(items)

        assertEquals(3, chunks.size)
        assertEquals(10, chunks[0].size)
        assertEquals(10, chunks[1].size)
        assertEquals(5, chunks[2].size)
        assertEquals((1..10).toList(), chunks[0])
    }

    @Test
    fun testChunkCustomSize() {
        val items = listOf("a", "b", "c", "d", "e")
        val chunks = NotionChunker.chunk(items, chunkSize = 2)

        assertEquals(3, chunks.size)
        assertEquals(listOf("a", "b"), chunks[0])
        assertEquals(listOf("c", "d"), chunks[1])
        assertEquals(listOf("e"), chunks[2])
    }

    @Test
    fun testScanDirectory() {
        val rootDir = tempFolder.newFolder("test_dir")
        val file1 = File(rootDir, "file1.txt").apply { writeText("hello") }
        val subDir = File(rootDir, "subdir").apply { mkdir() }
        val file2 = File(subDir, "file2.txt").apply { writeText("world") }

        val scannedFiles = NotionChunker.scanDirectory(rootDir)

        assertEquals(2, scannedFiles.size)
        assertTrue(scannedFiles.contains(file1))
        assertTrue(scannedFiles.contains(file2))
    }
}
