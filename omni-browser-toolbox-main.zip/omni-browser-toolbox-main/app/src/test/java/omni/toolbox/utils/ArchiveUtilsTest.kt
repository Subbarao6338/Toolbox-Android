package omni.toolbox.utils

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ArchiveUtilsTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    @Test
    fun testZipAndUnzipSingleFile() {
        val testFile = tempFolder.newFile("sample.txt")
        testFile.writeText("Hello, Omni Toolbox Archive Test!")

        val zipFile = File(tempFolder.root, "test_archive.zip")
        ArchiveUtils.zip(listOf(testFile), zipFile)

        assertTrue(zipFile.exists())
        assertTrue(zipFile.length() > 0)

        val outputDir = tempFolder.newFolder("unzipped")
        ArchiveUtils.unzip(zipFile, outputDir)

        val unzippedFile = File(outputDir, "sample.txt")
        assertTrue(unzippedFile.exists())
        assertEquals("Hello, Omni Toolbox Archive Test!", unzippedFile.readText())
    }

    @Test
    fun testZipAndUnzipDirectory() {
        val folderToZip = tempFolder.newFolder("my_folder")
        val subFile = File(folderToZip, "inside.txt")
        subFile.writeText("Nested file content")

        val subFolder = File(folderToZip, "sub_dir")
        subFolder.mkdirs()
        val nestedFile = File(subFolder, "nested.txt")
        nestedFile.writeText("Deep nested content")

        val zipFile = File(tempFolder.root, "folder_archive.zip")
        ArchiveUtils.zip(listOf(folderToZip), zipFile)

        assertTrue(zipFile.exists())

        val outputDir = tempFolder.newFolder("unzipped_folder")
        ArchiveUtils.unzip(zipFile, outputDir)

        val extractedSubFile = File(outputDir, "my_folder/inside.txt")
        val extractedNestedFile = File(outputDir, "my_folder/sub_dir/nested.txt")

        assertTrue(extractedSubFile.exists())
        assertEquals("Nested file content", extractedSubFile.readText())
        assertTrue(extractedNestedFile.exists())
        assertEquals("Deep nested content", extractedNestedFile.readText())
    }

    @Test(expected = SecurityException::class)
    fun testUnzipZipSlipVulnerability() {
        val maliciousZip = tempFolder.newFile("malicious.zip")
        ZipOutputStream(FileOutputStream(maliciousZip)).use { zos ->
            val entry = ZipEntry("../malicious_file.txt")
            zos.putNextEntry(entry)
            zos.write("Hacked!".toByteArray())
            zos.closeEntry()
        }

        val outputDir = tempFolder.newFolder("target_unzip")
        ArchiveUtils.unzip(maliciousZip, outputDir)
    }

    @Test
    fun test7zCreateAndExtractSingleFile() {
        val testFile = tempFolder.newFile("data.txt")
        testFile.writeText("7z Compression Test Data")

        val archive7z = File(tempFolder.root, "data.7z")
        ArchiveUtils.create7z(listOf(testFile), archive7z)

        assertTrue(archive7z.exists())
        assertTrue(archive7z.length() > 0)

        val outputDir = tempFolder.newFolder("extracted_7z")
        ArchiveUtils.extract7z(archive7z, outputDir)

        val extractedFile = File(outputDir, "data.txt")
        assertTrue(extractedFile.exists())
        assertEquals("7z Compression Test Data", extractedFile.readText())
    }

    @Test
    fun test7zCreateAndExtractDirectory() {
        val folderTo7z = tempFolder.newFolder("dir_7z")
        File(folderTo7z, "doc1.txt").writeText("Doc 1")
        val nested = File(folderTo7z, "nested")
        nested.mkdirs()
        File(nested, "doc2.txt").writeText("Doc 2")

        val archive7z = File(tempFolder.root, "dir_archive.7z")
        ArchiveUtils.create7z(listOf(folderTo7z), archive7z)

        assertTrue(archive7z.exists())

        val outputDir = tempFolder.newFolder("extracted_dir_7z")
        ArchiveUtils.extract7z(archive7z, outputDir)

        val extractedDoc1 = File(outputDir, "dir_7z/doc1.txt")
        val extractedDoc2 = File(outputDir, "dir_7z/nested/doc2.txt")

        assertTrue(extractedDoc1.exists())
        assertEquals("Doc 1", extractedDoc1.readText())
        assertTrue(extractedDoc2.exists())
        assertEquals("Doc 2", extractedDoc2.readText())
    }

    @Test(expected = SecurityException::class)
    fun testExtract7zZipSlipVulnerability() {
        val malicious7z = tempFolder.newFile("malicious.7z")
        org.apache.commons.compress.archivers.sevenz.SevenZOutputFile(malicious7z).use { out ->
            val sample = tempFolder.newFile("temp.txt")
            sample.writeText("Hacked!")
            val entry = out.createArchiveEntry(sample, "../malicious_file.txt")
            out.putArchiveEntry(entry)
            out.write("Hacked!".toByteArray())
            out.closeArchiveEntry()
        }

        val outputDir = tempFolder.newFolder("target_extract_7z")
        ArchiveUtils.extract7z(malicious7z, outputDir)
    }
}
