package omni.toolbox.utils

import omni.toolbox.utils.navigation.GeoUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GeoUtilsTest {

    @Test
    fun testCalculateDistanceSamePoint() {
        val distance = GeoUtils.calculateDistance(37.7749, -122.4194, 37.7749, -122.4194)
        assertEquals(0f, distance, 0.01f)
    }

    @Test
    fun testCalculateDistanceKnownPoints() {
        // San Francisco (37.7749, -122.4194) to Los Angeles (34.0522, -118.2437) ~ 559 km
        val distance = GeoUtils.calculateDistance(37.7749, -122.4194, 34.0522, -118.2437)
        assertEquals(559000f, distance, 10000f)
    }

    @Test
    fun testCalculateBearingNorth() {
        // From (0,0) to (1,0) should be 0 degrees (North)
        val bearing = GeoUtils.calculateBearing(0.0, 0.0, 1.0, 0.0)
        assertEquals(0f, bearing, 0.1f)
    }

    @Test
    fun testCalculateBearingEast() {
        // From (0,0) to (0,1) should be 90 degrees (East)
        val bearing = GeoUtils.calculateBearing(0.0, 0.0, 0.0, 1.0)
        assertEquals(90f, bearing, 0.1f)
    }

    @Test
    fun testDestinationCalculation() {
        val startLat = 0.0
        val startLon = 0.0
        val distanceMeters = 100000.0 // 100 km North
        val bearing = 0.0

        val (destLat, destLon) = GeoUtils.destination(startLat, startLon, distanceMeters, bearing)
        assertTrue(destLat > startLat)
        assertEquals(startLon, destLon, 0.001)

        val recalculatedDistance = GeoUtils.calculateDistance(startLat, startLon, destLat, destLon)
        assertEquals(distanceMeters.toFloat(), recalculatedDistance, 10f)
    }
}
