package omni.browser

import org.junit.Assert.*
import org.junit.Test
import omni.toolbox.ui.screens.productivity.encrypt
import omni.toolbox.ui.screens.productivity.decrypt
import omni.toolbox.ui.screens.productivity.generatePassword

class SecurityScreenTest {

    @Test
    fun testEncryptDecrypt_roundtrip() {
        val plaintext = "Hello World! This is a secure premium cryptographic test string."
        val key = "secretPassphrase123"

        val ciphertext = encrypt(plaintext, key)
        assertNotNull(ciphertext)
        assertNotEquals(plaintext, ciphertext)

        val decrypted = decrypt(ciphertext, key)
        assertEquals(plaintext, decrypted)
    }

    @Test
    fun testDecrypt_invalidPayload() {
        val invalidCiphertext = "ShortIV"
        val decrypted = decrypt(invalidCiphertext, "anykey")
        assertTrue(decrypted.startsWith("Error"))
    }

    @Test
    fun testDecrypt_wrongKey() {
        val plaintext = "Secret message to protect"
        val correctKey = "RightKey"
        val wrongKey = "WrongKey"

        val ciphertext = encrypt(plaintext, correctKey)
        val decryptedWithWrongKey = decrypt(ciphertext, wrongKey)
        assertTrue(decryptedWithWrongKey.startsWith("Error"))
    }

    @Test
    fun testGeneratePassword_lengthAndContent() {
        val length = 24
        val includeSymbols = true
        val includeNumbers = true

        val password = generatePassword(length, includeSymbols, includeNumbers)
        assertEquals(length, password.length)

        // Verify it contains characters from the character pool
        val charPool = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=[]{}|;:,.<>?"
        for (char in password) {
            assertTrue(charPool.contains(char))
        }
    }
}
