package omni.browser

import omni.browser.util.UrlUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UrlUtilsTest {

    private val searchEngine = "https://www.google.com/search?q="

    @Test
    fun testResolveUrl_ValidUrl() {
        assertEquals("https://google.com", UrlUtils.resolveUrl("google.com", searchEngine))
        assertEquals("https://www.github.com", UrlUtils.resolveUrl("www.github.com", searchEngine))
        assertEquals("https://example.com/path", UrlUtils.resolveUrl("https://example.com/path", searchEngine))
    }

    @Test
    fun testResolveUrl_SearchQuery() {
        assertEquals("${searchEngine}hello%20world", UrlUtils.resolveUrl("hello world", searchEngine))
        assertEquals("${searchEngine}testing", UrlUtils.resolveUrl("testing", searchEngine))
    }

    @Test
    fun testResolveUrl_Localhost() {
        assertEquals("http://localhost:8080", UrlUtils.resolveUrl("localhost:8080", searchEngine))
        assertEquals("http://127.0.0.1", UrlUtils.resolveUrl("127.0.0.1", searchEngine))
    }

    @Test
    fun testResolveUrl_AboutHome() {
        assertEquals("about:home", UrlUtils.resolveUrl("", searchEngine))
        assertEquals("about:home", UrlUtils.resolveUrl("   ", searchEngine))
    }

    @Test
    fun testIsBookmarklet() {
        assertEquals(true, UrlUtils.isBookmarklet("javascript:alert(1)"))
        assertEquals(false, UrlUtils.isBookmarklet("https://google.com"))
    }

    @Test
    fun testResolveUrl_Bangs() {
        // Test standard bang with query
        assertEquals("https://www.google.com/search?q=kotlin", UrlUtils.resolveUrl("!g kotlin", searchEngine))
        assertEquals("https://duckduckgo.com/?q=jetpack%20compose", UrlUtils.resolveUrl("!ddg jetpack compose", searchEngine))
        assertEquals("https://en.wikipedia.org/wiki/Special:Search?search=Android%20Studio", UrlUtils.resolveUrl("!w Android Studio", searchEngine))
        assertEquals("https://github.com/search?q=omni-web", UrlUtils.resolveUrl("!gh omni-web", searchEngine))

        // Test bang without query
        assertEquals("https://www.google.com/search?q=", UrlUtils.resolveUrl("!g", searchEngine))
    }

    @Test
    fun testResolveUrl_ChromeUrls() {
        assertEquals("about:home", UrlUtils.resolveUrl("chrome://home", searchEngine))
        assertEquals("about:home", UrlUtils.resolveUrl("chrome://home/", searchEngine))
        assertEquals("chrome://settings", UrlUtils.resolveUrl("chrome://settings", searchEngine))
    }

    @Test
    fun testResolveUrl_FilePaths() {
        assertEquals("file:///sdcard/download/test.pdf", UrlUtils.resolveUrl("/sdcard/download/test.pdf", searchEngine))
    }

    @Test
    fun testResolveUrl_SpecialUrlFormats() {
        // Param queries which look like url
        assertEquals("https://test.com?param=value", UrlUtils.resolveUrl("test.com?param=value", searchEngine))
        // Multiple subdomains
        assertEquals("https://sub.sub.domain.co.uk", UrlUtils.resolveUrl("sub.sub.domain.co.uk", searchEngine))
    }

    @Test
    fun testResolveUrl_EdgeCaseIPsAndPorts() {
        // Test sub-networks or remote servers with port numbers
        assertEquals("http://192.168.1.100:9000", UrlUtils.resolveUrl("192.168.1.100:9000", searchEngine))
        assertEquals("http://10.0.0.1:80", UrlUtils.resolveUrl("10.0.0.1:80", searchEngine))
        assertEquals("http://localhost:3000/api", UrlUtils.resolveUrl("localhost:3000/api", searchEngine))
    }

    @Test
    fun testResolveUrl_AdditionalBangs() {
        // Test other supported bangs from UrlUtils map
        assertEquals("https://www.youtube.com/results?search_query=lofi%20beats", UrlUtils.resolveUrl("!yt lofi beats", searchEngine))
        assertEquals("https://twitter.com/search?q=android", UrlUtils.resolveUrl("!tw android", searchEngine))
        assertEquals("https://stackoverflow.com/search?q=kotlin%20coroutines", UrlUtils.resolveUrl("!stack kotlin coroutines", searchEngine))
    }

    @Test
    fun testResolveUrl_SpacesAndPadding() {
        // Leading/trailing spacing with search queries
        assertEquals("${searchEngine}hello%20world", UrlUtils.resolveUrl("   hello world   ", searchEngine))
        // Leading/trailing spacing with URL
        assertEquals("https://google.com", UrlUtils.resolveUrl("   google.com   ", searchEngine))
    }

    @Test
    fun testResolveUrl_LongFormBangs() {
        // Test newly added long-form search bangs
        assertEquals("https://www.google.com/search?q=kotlin", UrlUtils.resolveUrl("!google kotlin", searchEngine))
        assertEquals("https://duckduckgo.com/?q=android%20compose", UrlUtils.resolveUrl("!duckduckgo android compose", searchEngine))
        assertEquals("https://en.wikipedia.org/wiki/Special:Search?search=Jetpack", UrlUtils.resolveUrl("!wikipedia Jetpack", searchEngine))
        assertEquals("https://www.youtube.com/results?search_query=music", UrlUtils.resolveUrl("!youtube music", searchEngine))
        assertEquals("https://github.com/search?q=omni", UrlUtils.resolveUrl("!github omni", searchEngine))
        assertEquals("https://www.bing.com/search?q=weather", UrlUtils.resolveUrl("!bing weather", searchEngine))
        assertEquals("https://www.amazon.com/s?k=books", UrlUtils.resolveUrl("!amazon books", searchEngine))
        assertEquals("https://twitter.com/search?q=news", UrlUtils.resolveUrl("!twitter news", searchEngine))
        assertEquals("https://stackoverflow.com/search?q=nullpointer", UrlUtils.resolveUrl("!stackoverflow nullpointer", searchEngine))
    }

    @Test
    fun testResolveUrl_SpecialCharactersEncoding() {
        // Test query encoding with complex special characters (including non-ASCII & URL-critical characters)
        // Java's standard URLEncoder fallback will correctly encode characters like '?', '&', '=', and Unicode
        assertEquals("https://www.google.com/search?q=hello%3F%26%3Dworld%20%E2%98%85", UrlUtils.resolveUrl("!google hello?&=world ★", searchEngine))
    }

    @Test
    fun testResolveUrl_NewDeveloperBangs() {
        assertEquals("https://doc.rust-lang.org/std/?search=vec", UrlUtils.resolveUrl("!rust vec", searchEngine))
        assertEquals("https://docs.python.org/3/search.html?q=asyncio", UrlUtils.resolveUrl("!py asyncio", searchEngine))
        assertEquals("https://docs.python.org/3/search.html?q=asyncio", UrlUtils.resolveUrl("!python asyncio", searchEngine))
        assertEquals("https://www.npmjs.com/search?q=react", UrlUtils.resolveUrl("!npm react", searchEngine))
        assertEquals("https://pkg.go.dev/search?q=http", UrlUtils.resolveUrl("!go http", searchEngine))
        assertEquals("https://pkg.go.dev/search?q=http", UrlUtils.resolveUrl("!golang http", searchEngine))
    }

    @Test
    fun testResolveUrl_CaseInsensitiveBangs() {
        assertEquals("https://www.google.com/search?q=kotlin", UrlUtils.resolveUrl("!G kotlin", searchEngine))
        assertEquals("https://www.google.com/search?q=kotlin", UrlUtils.resolveUrl("!GOOGLE kotlin", searchEngine))
        assertEquals("https://github.com/search?q=omni", UrlUtils.resolveUrl("!GH omni", searchEngine))
        assertEquals("https://doc.rust-lang.org/std/?search=vec", UrlUtils.resolveUrl("!RUST vec", searchEngine))
    }
}
