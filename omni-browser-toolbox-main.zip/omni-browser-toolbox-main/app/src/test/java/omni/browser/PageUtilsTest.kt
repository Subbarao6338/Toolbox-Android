package omni.browser

import omni.browser.util.PageUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PageUtilsTest {

    @Test
    fun testHtmlToMarkdown_Headings() {
        val html = """
            <h1>Heading 1</h1>
            <h2>Heading 2</h2>
            <h3>Heading 3</h3>
            <h4>Heading 4</h4>
            <h5>Heading 5</h5>
            <h6>Heading 6</h6>
        """.trimIndent()

        val markdown = PageUtils.htmlToMarkdown(html)

        assertTrue(markdown.contains("# Heading 1"))
        assertTrue(markdown.contains("## Heading 2"))
        assertTrue(markdown.contains("### Heading 3"))
        assertTrue(markdown.contains("#### Heading 4"))
        assertTrue(markdown.contains("##### Heading 5"))
        assertTrue(markdown.contains("###### Heading 6"))
    }

    @Test
    fun testHtmlToMarkdown_FormattingAndLinks() {
        val html = """
            <p>This is <strong>bold</strong> and <em>italic</em> text with a <a href="https://example.com">link</a>.</p>
        """.trimIndent()

        val markdown = PageUtils.htmlToMarkdown(html)

        assertTrue(markdown.contains("**bold**"))
        assertTrue(markdown.contains("*italic*"))
        assertTrue(markdown.contains("[link](https://example.com)"))
    }

    @Test
    fun testHtmlToMarkdown_Lists() {
        val html = """
            <ul>
                <li>Item A</li>
                <li>Item B</li>
            </ul>
        """.trimIndent()

        val markdown = PageUtils.htmlToMarkdown(html)

        assertTrue(markdown.contains("- Item A"))
        assertTrue(markdown.contains("- Item B"))
    }

    @Test
    fun testHtmlToMarkdown_BlockquoteAndHr() {
        val html = """
            <blockquote>A famous quote</blockquote>
            <hr>
            <p>After line</p>
        """.trimIndent()

        val markdown = PageUtils.htmlToMarkdown(html)

        assertTrue(markdown.contains("> A famous quote"))
        assertTrue(markdown.contains("---"))
        assertTrue(markdown.contains("After line"))
    }

    @Test
    fun testHtmlToMarkdown_CodeAndPre() {
        val html = """
            <p>Inline <code>code</code> block:</p>
            <pre>val x = 10</pre>
        """.trimIndent()

        val markdown = PageUtils.htmlToMarkdown(html)

        assertTrue(markdown.contains("`code`"))
        assertTrue(markdown.contains("```\nval x = 10\n```"))
    }

    @Test
    fun testHtmlToMarkdown_Table() {
        val html = """
            <table>
                <tr><th>Header 1</th><th>Header 2</th></tr>
                <tr><td>Value 1</td><td>Value 2</td></tr>
            </table>
        """.trimIndent()

        val markdown = PageUtils.htmlToMarkdown(html)

        assertTrue(markdown.contains("Header 1"))
        assertTrue(markdown.contains("Header 2"))
        assertTrue(markdown.contains("---"))
        assertTrue(markdown.contains("Value 1"))
        assertTrue(markdown.contains("Value 2"))
    }
}
