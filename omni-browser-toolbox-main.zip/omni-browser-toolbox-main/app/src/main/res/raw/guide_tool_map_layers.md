Layers are used to display information on the map, they are configurable on the Navigation, Photo Maps, and Map tool. See the respective tool guides for how to access the layer settings.

Some layers are time dependent (marked below). When viewing these layers in the Map tool, you can change the map time to see them at different times. In other tools, they always display the current time.

On the layer settings panel, the higher up a layer is in the list, the more "on top" it will be drawn on the map. You can use the arrows on the left side to adjust the order of the layers.

Click on the layer's name to expand its settings.

You can use the "Additional layers" button at the bottom of the layers list to add additional layers.

Each layer has the following settings:

- **Visible**: Determines if the layer is shown on the map. When it is not visible, the layer header will be grayed out.
- **Opacity**: Determines how transparent the layer is. 0 is fully transparent and 100 is fully opaque.
- **Copy settings to other maps**: Copy the layer settings to other maps. Clicking this will open a dialog where you can choose which maps to copy the settings to.
- **Remove layer**:: Remove this layer from the active layer list. You can re-add it via the "Additional layers" button.

## Base map
This layer shows a map of the world with colors based on satellite imagery. It is very low resolution and not suitable for navigation.

## Elevation
This layer shows the elevation from the digital elevation model (DEM) as color.

Settings:

- **Digital elevation model (DEM)**: Links to Settings > Altimeter to configure the DEM source.
- **Color**: The color scale of the pixels. The color will change based on elevation.
- **High resolution**: If enabled, the resolution will be increased when zoomed out. This may be slower.

## Hillshade
This layer draws shadows to help see elevation in the terrain from the digital elevation model (DEM).

Settings:

- **Digital elevation model (DEM)**: Links to Settings > Altimeter to configure the DEM source.
- **Draw accurate shadows**: If enabled, shadows will be drawn using the position of the sun and moon (time dependent), but the 3D appearance may be reduced.
- **Multi-direction shading**: If enabled, shadows will be calculated from multiple light directions to enhance terrain details.
- **High resolution**: If enabled, the resolution will be increased when zoomed out. This may be slower.

## Slope
This layer colors the terrain by steepness using the digital elevation model (DEM).

Settings:

- **Digital elevation model (DEM)**: Links to Settings > Altimeter to configure the DEM source.
- **Color**: The color scale of the pixels. The color will change based on slope steepness.
  - **Green to red**: Green for flat areas, yellow for moderate slopes, and red for steep slopes.
  - **White to red**: White for flat areas, yellow for moderate slopes, and red for steep slopes.
  - **Grayscale**: Black for flat areas to white for steep slopes.
- **Smooth**: If enabled, the slope colors will be smoothed so you can better see gradual changes.
- **Hide flat ground**: If enabled, flat ground (slope below 10 degrees) will be invisible.
- **High resolution**: If enabled, the resolution will be increased when zoomed out. This may be slower.

## Ruggedness
This layer colors the terrain by how much the elevation changes around it (ruggedness index).

Low ruggedness is green, moderate is yellow/orange, and highly rugged terrain is red.

Settings:

- **Digital elevation model (DEM)**: Links to Settings > Altimeter to configure the DEM source.
- **High resolution**: If enabled, the resolution will be increased when zoomed out. This may be slower.

## Aspect
This layer colors the terrain by aspect (the direction the slope is facing) using the digital elevation model (DEM).

Green = North, Blue = East, Red = South, Orange = West

Settings:

- **Digital elevation model (DEM)**: Links to Settings > Altimeter to configure the DEM source.
- **High resolution**: If enabled, the resolution will be increased when zoomed out. This may be slower.

## Photo Maps
This layer shows visible Photo Maps, with the most zoomed-in map appearing on top. You can add new maps in the Photo Maps tool.

Settings:

- **Load PDF tiles**: If enabled, PDF tiles will be loaded for maps that have a PDF version available. This is slower but provides higher resolution maps.

## Contours
This layer shows contour lines generated from the digital elevation model (DEM) and can be used to see the steepness and elevation of map features.

Settings:

- **Digital elevation model (DEM)**: Links to Settings > Altimeter to configure the DEM source.
- **Show labels**: Determines if contour labels are shown on the map.
- **Color**: The color of the contour lines, some options are color scales which change based on elevation.

## Solar Eclipse
This layer shows the solar eclipse visibility (time dependent).

Black = total eclipse, Gray = partial eclipse

Settings:

- **Smooth**: If enabled, the eclipse visibility will be smoothed so you can better see gradual changes. Makes it harder to see where the total eclipse is though.
- **Show path**: If enabled, the path of the eclipse is shown instead of the current visibility.

## Lunar Eclipse
This layer shows the lunar eclipse visibility (time dependent).

Orange = eclipse is visible

Settings:

- **Show path**: If enabled, the path of the eclipse is shown instead of the current visibility.

## Night
This layer shows where it is nighttime based on the sun's altitude (time dependent).

Black = sun well below horizon, Gray = sun just below horizon

Settings:

- **Smooth**: If enabled, the darkness will be smoothed so you can better see gradual changes between day and night.

## Cell towers
This layer shows nearby cell towers with the accuracy of the tower's location shown as a circle under the tower. These are approximate tower locations from OpenCelliD, Mozilla Location Service, and FCC Antenna Registrations. You can click on a cell tower to navigate to it.

## Paths
This layer shows visible paths. You can add new paths in the Paths tool.

Settings:

- **Background color**: The background color to render behind paths for increased visibility.

## Beacons
This layer shows visible beacons. You can add new beacons in the Beacons tool. You can click on a beacon to navigate to it.

## Navigation
This layer draws a line between your location and the destination point you are navigating to.

## Tides
This layer shows visible tides (time dependent). You can add new tides in the Tides tool.

Settings:

- **Show modeled tides on coastline**: If enabled, tides will be loaded from the built-in model on the coastline.
- **Show tide phase**: If enabled, tides will display the current phase direction instead of the high/low tide icon.

## Sightings
This layer shows your field guide sightings with location data. The icon displayed represents the classification of the field guide entry (plant, bird, mammal, etc.). You can click on a sighting to navigate to it.

Settings:

- **Show images**: If enabled, the field guide page's image will be displayed instead of the category icon.

## Location
This layer shows your location, which direction you are facing (if you have a compass), and the accuracy of your GPS.

Settings:

- **Show GPS accuracy**: Determines if the GPS accuracy circle is visible.
- **Large location indicator**: If enabled, the location marker will be larger.

## Scale
This layer shows a scale bar in the bottom-left corner of the map, which can be used to estimate distances on the map.

This layer is not currently configurable.

## Elevation
This layer shows your elevation in the bottom-right corner of the map.

This layer is not currently configurable.

## Compass
This layer shows a compass in the top-right corner of the map. It shows where true north is on the map.

This layer is not currently configurable.
