The Field Guide tool can be used to identify plants, animals, and other objects in the wild.

## Pages
Pages are organized into categories, such as plants and animals. You can click on a category to view the pages. The name, image, and the first sentence of the page's notes are displayed for each item. Click on an item to view the full page. On pages that you created, you will see a menu button that allows you to edit or delete the page.

You can search for pages by name, notes, or tags. The search results will be displayed as you type.

## Built-in pages
Trail Sense includes a set of built-in pages that cover common plants, animals, mushrooms, and rocks that are beneficial for wilderness survival. You can not edit or delete these pages.

## Create a page
To create a new page, click the add button in the bottom right corner of the screen. You can add a name, image, notes, and tags to the page. The image can be taken with the camera or selected from the gallery. You can click the check button in the top right corner to save the page.

If you had a category selected when you created the page, the new page will be pre-filled with that category. Pages without a category will be displayed in the "Other" category.

## Edit a page
To edit a page, click the menu button on a page row and select "Edit". You can change the name, image, notes, and tags of the page. You can click the check button in the top right corner to save the changes.

## Sightings
You can view and record sightings for a field guide entry by clicking the "Sightings" link under the field guide page's image. This opens the list of sightings which show the time of time and notes. The total count of sightings is displayed next to the sighting link on the entry's page.

You can create a new sighting by clicking the plus button in the bottom right of the sightings list. You can fill out the time, location, elevation, whether it was harvested, whether to show on map, and notes. All fields are optional. Click the check button in the top right to save the sighting.

You can edit a sighting by clicking on it in the sightings list or using the menu on the right and selecting "Edit".

You can delete a sighting by using the menu on the right and selecting "Delete".

You can navigate to a sighting by using the menu on the right and selecting "Navigate". This will open the Navigation tool with the sighting's location as the destination.

You can create a beacon from a sighting by using the menu on the right and selecting "Create beacon". This will open the Beacons tool with a new beacon pre-filled with the sighting's location and name.

## Map layer visibility
You can hide individual sightings from appearing on the Sightings map layer. When creating or editing a sighting, toggle the "Show on map" switch off to hide the sighting from the map. By default, sightings are shown on the map.

## Delete a page
To delete a page, click the menu button on a page row and select "Delete". You will be asked to confirm the deletion. Deleting a page is permanent and cannot be undone.

## Disclaimer
This tool is intended for educational purposes only. Always use caution when identifying plants, animals, or mushrooms. Some species may be dangerous or protected. If you are unsure about an identification, consult a professional.
