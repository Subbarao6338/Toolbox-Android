package omni.toolbox.ui.theme

import androidx.compose.ui.graphics.Color

// Omni Toolbox Slate-Carbon Theme
val NeonMint = Color(0xFF39FF14)
val SlateDark = Color(0xFF121212)
val CarbonGray = Color(0xFF1E1E1E)
val SoftWhite = Color(0xFFFFFFFF)

// Nature-Inspired Colors
val LeafGreen = Color(0xFF4CAF50)
val DarkLeafGreen = Color(0xFF388E3C)
val EarthBrown = Color(0xFF795548)
val DarkEarthBrown = Color(0xFF5D4037)
val SkyBlue = Color(0xFF2196F3)
val DarkSkyBlue = Color(0xFF1976D2)
val ClayRed = Color(0xFFF44336)
val EarthyYellow = Color(0xFFFFC107)

// Light Theme Neutrals
val NatureWhite = Color(0xFFFFFFFF)
val NatureBeige = Color(0xFFF5F5DC)

// Dark Theme Neutrals
val ForestNight = Color(0xFF1B261E)
val DeepBark = Color(0xFF2A211D)

// Additional Accent Colors
val Sunflower = Color(0xFFFFEB3B)
val Orange = Color(0xFFFF9800)
val DeepOrange = Color(0xFFFF5722)
val Pink = Color(0xFFE91E63)
val Purple = Color(0xFF9C27B0)
val DeepPurple = Color(0xFF673AB7)
val Indigo = Color(0xFF3F51B5)
val Blue = Color(0xFF2196F3)
val Cyan = Color(0xFF00BCD4)
val Teal = Color(0xFF009688)
val LightGreen = Color(0xFF8BC34A)
val Lime = Color(0xFFCDDC39)
val Amber = Color(0xFFFFC107)
val Brown = Color(0xFF795548)
val Grey = Color(0xFF9E9E9E)
val BlueGrey = Color(0xFF607D8B)
val Crimson = Color(0xFFDC143C)
val Coral = Color(0xFFFF7F50)
val Gold = Color(0xFFFFD700)
val Olive = Color(0xFF808000)
val Navy = Color(0xFF000080)
val Slate = Color(0xFF708090)
val Orchid = Color(0xFFDA70D6)

val AccentColors = listOf(
    LeafGreen, EarthBrown, SkyBlue, ClayRed, Sunflower, Orange, DeepOrange,
    Pink, Purple, DeepPurple, Indigo, Blue, Cyan, Teal, LightGreen,
    Lime, Amber, Brown, Grey, BlueGrey, Crimson, Coral, Gold, Olive, Navy, Slate, Orchid
)

// Define Custom Palette Colors for Synchronized Themes
// Default / Epic Indigo/Slate
val EpicPrimary = Color(0xFF4F46E5)
val EpicSecondary = Color(0xFF6366F1)
val EpicBgLight = Color(0xFFF8FAFC)
val EpicSurfaceLight = Color.White
val EpicBgDark = Color(0xFF0F172A)
val EpicSurfaceDark = Color(0xFF0F172A)

// Earth Theme Colors
val EarthPrimary = Color(0xFF795548)
val EarthSecondary = Color(0xFF8D6E63)
val EarthBgLight = Color(0xFFF5F5DC) // Warm Beige
val EarthSurfaceLight = Color(0xFFFFFDF9)
val EarthBgDark = Color(0xFF2A211D) // Deep Bark
val EarthSurfaceDark = Color(0xFF352B26)

// Forest Theme Colors
val ForestPrimary = Color(0xFF2E7D32)
val ForestSecondary = Color(0xFF4CAF50)
val ForestBgLight = Color(0xFFF1F8E9) // Pale Green/Sage
val ForestSurfaceLight = Color(0xFFFFFDF9)
val ForestBgDark = Color(0xFF1B261E) // Forest Night
val ForestSurfaceDark = Color(0xFF243027)

// Water Theme Colors
val WaterPrimary = Color(0xFF0277BD)
val WaterSecondary = Color(0xFF039BE5)
val WaterBgLight = Color(0xFFE0F7FA) // Ocean Blue/Cyan Tint
val WaterSurfaceLight = Color(0xFFFFFDF9)
val WaterBgDark = Color(0xFF0D1B2A) // Deep Water Blue
val WaterSurfaceDark = Color(0xFF1B2A4A)

// Sand Theme Colors
val SandPrimary = Color(0xFFFBC02D)
val SandSecondary = Color(0xFFFDD835)
val SandBgLight = Color(0xFFFFF8E1) // Warm Sand / Gold Tint
val SandSurfaceLight = Color(0xFFFFFDF9)
val SandBgDark = Color(0xFF1C1A17) // Deep Sand
val SandSurfaceDark = Color(0xFF282521)

// Nature Theme Colors
val NaturePrimary = Color(0xFF1B4D3E) // Rich dark organic green
val NatureSecondary = Color(0xFF386641) // Secondary organic green
val NatureBgLight = Color(0xFFF5F2EB) // Bone / light ivory background
val NatureSurfaceLight = Color(0xFFFFFDF9)
val NatureBgDark = Color(0xFF0D1411) // Deep forest green night
val NatureSurfaceDark = Color(0xFF16201A)
