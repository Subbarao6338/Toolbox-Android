package omni.toolbox.ui.screens.conversion

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import android.content.Context
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import omni.toolbox.ui.components.ToolScreen
import org.json.JSONObject

@Composable
fun CurrencyConverterScreen(navController: NavHostController) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("currency_rates", Context.MODE_PRIVATE) }

    var amount by remember { mutableStateOf("") }
    var fromCurrency by remember { mutableStateOf("USD") }
    var toCurrency by remember { mutableStateOf("EUR") }

    // Initial rates
    val initialRates = mapOf(
        "USD" to 1.0,
        "EUR" to 0.92,
        "GBP" to 0.79,
        "JPY" to 151.0,
        "AUD" to 1.52,
        "CAD" to 1.35,
        "CHF" to 0.90,
        "CNY" to 7.23,
        "INR" to 83.3,
        "BRL" to 5.05
    )

    var rates by remember {
        mutableStateOf(
            prefs.getString("latest", null)?.let { json ->
                try {
                    val obj = JSONObject(json)
                    val map = mutableMapOf<String, Double>()
                    obj.keys().forEach { map[it] = obj.getDouble(it) }
                    map
                } catch(e: Exception) { initialRates }
            } ?: initialRates
        )
    }

    val currencies = rates.keys.toList()

    val result = try {
        val value = amount.toDoubleOrNull() ?: 0.0
        val base = value / (rates[fromCurrency] ?: 1.0)
        base * (rates[toCurrency] ?: 1.0)
    } catch (e: Exception) {
        0.0
    }

    // Perspective: Simulation of rate fetching and caching
    LaunchedEffect(Unit) {
        // In a real app, fetch from API here. For now, we "cache" the initial/stored rates.
        val json = JSONObject(rates as Map<*, *>).toString()
        prefs.edit().putString("latest", json).apply()
    }

    ToolScreen(title = "Currency Converter", onBack = { navController.popBackStack() }) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text("Amount") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                CurrencyDropdown("From", fromCurrency, currencies, { fromCurrency = it }, Modifier.weight(1f))
                IconButton(onClick = {
                    val temp = fromCurrency
                    fromCurrency = toCurrency
                    toCurrency = temp
                }) {
                    Icon(Icons.Default.SwapHoriz, contentDescription = "Swap")
                }
                CurrencyDropdown("To", toCurrency, currencies, { toCurrency = it }, Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(32.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Result", style = MaterialTheme.typography.labelLarge)
                    Text(
                        java.lang.String.format(java.util.Locale.US, "%.2f", result),
                        style = MaterialTheme.typography.displayMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(toCurrency, style = MaterialTheme.typography.titleMedium)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text("Rates are cached for offline use.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CurrencyDropdown(label: String, selected: String, options: List<String>, onSelect: (String) -> Unit, modifier: Modifier) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(text = { Text(option) }, onClick = { onSelect(option); expanded = false })
            }
        }
    }
}
